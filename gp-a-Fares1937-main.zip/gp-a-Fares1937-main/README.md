# gp-a-starter

## Guided Practice A - GitHub Practice

Example repository used with the GitHub tutorial assignment

Here is my CS 1110 POTD assignments!
...

I think they all work... can you check them for me?
